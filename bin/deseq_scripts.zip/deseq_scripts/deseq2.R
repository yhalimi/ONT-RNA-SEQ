## ----setup, include=FALSE------------------------------------------------------------------------------------------------------------------------------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
false=FALSE
true=TRUE


## ---- eval=false, echo=false---------------------------------------------------------------------------------------------------------------------------------------------------------------------
install.packages(c('dplyr','gplots','ggplot2','ggrepel'))


## ---- eval=false, echo=false---------------------------------------------------------------------------------------------------------------------------------------------------------------------
BiocManager::install(c('limma','DESeq2','AnnotationDbi','org.Mm.eg.db','ReportingTools','GO.db','GOstats','pathview','gage','gageData','select'))


## ---- message=false, echo=false------------------------------------------------------------------------------------------------------------------------------------------------------------------
library(DESeq2)
library(dplyr)

countData = read.csv('readCounts.csv', header=1)


## ---- echo=false---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
rownames(countData) = countData$Geneid
countData = countData[,-1]


## ---- message=false, echo=false------------------------------------------------------------------------------------------------------------------------------------------------------------------
logCountData = log2(1+countData)


## ---- message=false, echo=false------------------------------------------------------------------------------------------------------------------------------------------------------------------
p53 = c("m","m","m","m",
        "p","p","p","p","p","p","p","p")
treatment = c("control","control","IR","IR","control","control","control","control",
              "IR","IR","IR","IR")


## ---- message=false, echo=false, warning=FALSE---------------------------------------------------------------------------------------------------------------------------------------------------
colData = as.data.frame(cbind(colnames(countData),p53,treatment))


## ---- message=false, echo=false, warning=FALSE---------------------------------------------------------------------------------------------------------------------------------------------------
dds = DESeqDataSetFromMatrix(countData = countData, 
                             colData = colData, 
                             design = ~p53+treatment+p53*treatment)
dds = DESeq(dds)


## ---- message=false, echo=false------------------------------------------------------------------------------------------------------------------------------------------------------------------
dds = dds[rowSums(counts(dds)) >5,]


## ---- message=false, echo=false------------------------------------------------------------------------------------------------------------------------------------------------------------------


## ---- message=false, echo=false------------------------------------------------------------------------------------------------------------------------------------------------------------------
library(ggplot2)
rld = rlog(dds)
plotPCA(rld, intgroup = "p53")
plotPCA(rld, intgroup = "treatment")
plotPCA(rld, intgroup = c("p53","treatment"))


## ---- message=false, echo=false------------------------------------------------------------------------------------------------------------------------------------------------------------------
detectGroups <- function (x){  # x are col names
  tem <- gsub("[0-9]*$","",x) # Remove all numbers from end
  #tem = gsub("_Rep|_rep|_REP","",tem)
  tem <- gsub("_$","",tem); # remove "_" from end
  tem <- gsub("_Rep$","",tem); # remove "_Rep" from end
  tem <- gsub("_rep$","",tem); # remove "_rep" from end
  tem <- gsub("_REP$","",tem)  # remove "_REP" from end
  return( tem )
}
dist2 <- function(x, ...)   # distance function = 1-PCC (Pearson's correlation coefficient)
  as.dist(1-cor(t(x), method="pearson"))


## ---- message=false, echo=false------------------------------------------------------------------------------------------------------------------------------------------------------------------


## ---- echo=false---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
res = results(dds)


## ---- message=false, echo=false------------------------------------------------------------------------------------------------------------------------------------------------------------------
res = results(dds, lfcThreshold = 0.01)


## ---- message=false, echo=false------------------------------------------------------------------------------------------------------------------------------------------------------------------
DESeq2::plotMA(res,ylim=c(-5,5))


## ---- message=false, echo=false------------------------------------------------------------------------------------------------------------------------------------------------------------------
library(dplyr)
res1 = as.data.frame(res)

res1 = mutate(res1, sig=ifelse(res1$padj<0.1,"FDR<0.1","Not Sig"))
res1[which(abs(res1$log2FoldChange)<1.0), "sig"]="Not Sig"


## ---- message=false, echo=false, warning=false---------------------------------------------------------------------------------------------------------------------------------------------------
library(ggplot2)
ggplot(res1,aes(log2FoldChange,-log10(padj))) + geom_point(aes(col=sig))+scale_color_manual(values=c("red","black"))



## ---- message=false, echo=false------------------------------------------------------------------------------------------------------------------------------------------------------------------
res = res[order(abs(res$log2FoldChange), decreasing = true), ]
topGene = rownames(res)[1]
plotCounts(dds, gene=topGene, intgroup = c("p53","treatment"))


## ---- message=false, echo=false------------------------------------------------------------------------------------------------------------------------------------------------------------------
library(AnnotationDbi)
library(org.Mm.eg.db)


## ---- message=false, echo=false------------------------------------------------------------------------------------------------------------------------------------------------------------------
res$refseq=gsub("\\..*","", row.names(res))


## ---- message=false, echo=false------------------------------------------------------------------------------------------------------------------------------------------------------------------
res$SYMBOL = mapIds(org.Mm.eg.db, 
                    key=res$refseq, 
                    column="SYMBOL", 
                    keytype="REFSEQ", 
                    multiVals="first")
res$ENTREZ = mapIds(org.Mm.eg.db,
                    key=res$refseq,
                    column="ENTREZID",
                    keytype="REFSEQ",
                    multiVals = "first")
head(res)


## ---- message=false, echo=false------------------------------------------------------------------------------------------------------------------------------------------------------------------
write.csv(res, file="deseq2_output.csv")

